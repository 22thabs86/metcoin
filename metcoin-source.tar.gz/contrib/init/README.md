Sample configuration files for:
```
SystemD: metcoind.service
Upstart: metcoind.conf
OpenRC:  metcoind.openrc
         metcoind.openrcconf
CentOS:  metcoind.init
macOS:    org.metcoin.metcoind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
